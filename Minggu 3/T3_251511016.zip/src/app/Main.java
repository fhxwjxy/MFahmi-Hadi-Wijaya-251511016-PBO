package app;

import model.Mahasiswa;
import model.MenuItem;
import model.Pesanan;

public class Main {
    public static void main(String[] args) {
        Mahasiswa mhs1 = new Mahasiswa("241001", "Asep");
        Mahasiswa mhs2 = new Mahasiswa("241002", "Siti");

        MenuItem menu1 = new MenuItem("M01", "Nasi Goreng", 18000);
        MenuItem menu2 = new MenuItem("M02", "Kopi Susu", 12000);

        Pesanan p1 = new Pesanan(mhs1, menu1, 2);
        Pesanan p2 = new Pesanan(mhs2, menu2, 1);
        Pesanan p3 = new Pesanan(mhs1, menu2, 3);

        System.out.println(p1.ringkasan());
        System.out.println("Total P1: " + p1.hitungTotal());
        System.out.println("Status P1: " + p1.getStatus());
        Kasir kasir = new Kasir();
        kasir.proses(p1);

        System.out.println(p2.ringkasan());
        System.out.println("Status P2: " + p2.getStatus());
        kasir.proses(p2);

        System.out.println(p3.ringkasan());
        System.out.println("Jumlah pesanan dibuat: " + Pesanan.getJumlahPesananDibuat());
    }
}